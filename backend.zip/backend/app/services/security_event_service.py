from sqlalchemy.orm import Session

from backend.app.models.indicator import Indicator
from backend.app.models.security_event import SecurityEvent
from backend.app.schemas.security_event import SecurityEventCreate
from backend.app.services import alert_service


async def ingest_security_event(
    db: Session,
    event: SecurityEventCreate,
):
    security_event = SecurityEvent(
        source=event.source,
        event_type=event.event_type,
        category=event.category,
        indicator_value=event.indicator_value,
        timestamp=event.timestamp,
    )

    db.add(security_event)
    db.commit()
    db.refresh(security_event)

    indicator = (
        db.query(Indicator)
        .filter(
            Indicator.value == security_event.indicator_value
        )
        .first()
    )

    if indicator is not None:
        await alert_service.generate_alert_for_indicator(
            db=db,
            indicator=indicator,
            rule="Internal security event correlation",
        )

    return security_event


def find_events_for_indicator(
    db: Session,
    indicator_value: str,
):
    return (
        db.query(SecurityEvent)
        .filter(
            SecurityEvent.indicator_value == indicator_value
        )
        .order_by(
            SecurityEvent.timestamp.desc()
        )
        .all()
    )


def count_events_for_indicator(
    db: Session,
    indicator_value: str,
):
    return (
        db.query(SecurityEvent)
        .filter(
            SecurityEvent.indicator_value == indicator_value
        )
        .count()
    )


def get_security_events(
    db: Session,
):
    return (
        db.query(SecurityEvent)
        .order_by(
            SecurityEvent.timestamp.desc()
        )
        .all()
    )